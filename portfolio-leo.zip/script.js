function addProject(){
  let name = document.getElementById("name").value;
  let desc = document.getElementById("desc").value;

  let projects = JSON.parse(localStorage.getItem("projects")) || [];
  projects.push({name, desc});
  localStorage.setItem("projects", JSON.stringify(projects));
  render();
}

function render(){
  let list = document.getElementById("projectList");
  if(!list) return;

  let projects = JSON.parse(localStorage.getItem("projects")) || [];
  list.innerHTML = "";

  projects.forEach(p=>{
    list.innerHTML += `<div><h3>${p.name}</h3><p>${p.desc}</p></div>`;
  });
}

render();
