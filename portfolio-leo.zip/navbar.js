document.addEventListener("DOMContentLoaded", () => {
  document.body.insertAdjacentHTML("afterbegin", `
    <div class="navbar">
      <a href="index.html">Accueil</a>
      <a href="about.html">À propos</a>
      <a href="projects.html">Projets</a>
      <a href="contact.html">Contact</a>
      <a href="admin.html">Admin</a>
    </div>
  `);
});
